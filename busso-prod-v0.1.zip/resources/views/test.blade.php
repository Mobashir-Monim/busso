@extends('layouts.dashboard')

@section('content')
    henlo
@endsection