<input type="hidden" id="SAMLRequest" name="SAMLRequest" value="{{ request()->SAMLRequest }}">
<input type="hidden" name="RelayState" value="{{ request()->RelayState }}">