<a class="nav-item container-fluid" href="<?php echo e(route('roles')); ?>">
    <li class="nav-link text-white <?php echo e(startsWith(request()->url(), route('roles')) ? 'active' : ''); ?> row">
        <i class="fas fa-exclamation-triangle pr-1 col-2 my-auto"></i><span class="d-inline-block col-10">Role <?php echo request()->url() == route('roles') ? '<span class="sr-only">(current)</span>' : ''; ?></span>
    </li>
</a><?php /**PATH /Users/mobashirmonim/Documents/busso/resources/views/layouts/nav/items/role.blade.php ENDPATH**/ ?>