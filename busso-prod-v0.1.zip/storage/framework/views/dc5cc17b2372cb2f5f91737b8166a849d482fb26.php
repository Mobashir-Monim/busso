<span class="nav-item container-fluid d-md-none">
    <li class="nav-link text-white row">
        <form action="<?php echo e(route('logout')); ?>" method="post">
            <?php echo csrf_field(); ?>
            <i class="fas fa-power-off pr-1 col-2 my-auto"></i><span class="d-inline-block col-10">Logout</span>
        </form>
    </li>
</span><?php /**PATH /Users/mobashirmonim/Documents/busso/resources/views/layouts/nav/items/logout.blade.php ENDPATH**/ ?>