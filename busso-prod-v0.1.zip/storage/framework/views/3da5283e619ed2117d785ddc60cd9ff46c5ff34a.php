<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <h3 class="border-bottom border-3 border-primary">Resource Group</h3>
        </div>
    </div>
    <div class="row mb-4">
        <div class="col-md-8 my-2">
            <div class="card card-rounded">
                <div class="card-body">
                    <h4 class="border-bottom border-3 border-primary"><?php echo e($group->name); ?></h4>
                    <div class="row">
                        <div class="col-md-12 mb-2"><?php echo e($group->description); ?></div>
                    </div>
                    <div class="row">
                        <div class="col-md-4 mb-2 d-md-none"><b class="border-bottom d-block">Configured URL:</b></div>
                        <div class="col-md-4 mb-2 d-none d-md-block"><b>Configured URL:</b></div>
                        <div class="col-md-8 mb-2">
                            <?php echo e($group->url); ?>

                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-4 mb-2 d-md-none my-auto"><b class="border-bottom d-block">Configured for:</b></div>
                        <div class="col-md-4 mb-2 d-none d-md-block my-auto"><b>Configured for:</b></div>
                        <div class="col-md-8 mb-2">
                            <ul class="list-group list-group-horizontal">
                                <?php if(!is_null($group->saml)): ?>
                                    <li class="list-group-item">SAML</li>
                                <?php endif; ?>

                                <?php if(!is_null($group->oauth)): ?>
                                    <li class="list-group-item">Oauth/OIDC</li>
                                <?php endif; ?>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md"></div>
        <div class="col-md-2 my-2">
            <div class="card card-rounded">
                <div class="card-body rg-image card-rounded"
                    style="background-image: url('<?php echo e(is_null($group->image) ? "/img/rg-placeholder.png" : Storage::url("$group->image")); ?>');">
                </div>
            </div>
        </div>
    </div>

    <?php echo $__env->make('resource-group.oauth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('resource-group.saml', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/mobashirmonim/Documents/busso/resources/views/resource-group/show.blade.php ENDPATH**/ ?>