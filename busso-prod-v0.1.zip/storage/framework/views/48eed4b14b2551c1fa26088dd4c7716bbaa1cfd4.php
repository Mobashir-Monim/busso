<a class="nav-item container-fluid" href="<?php echo e(route('claims')); ?>">
    <li class="nav-link text-white <?php echo e(startsWith(request()->url(), route('claims')) ? 'active' : ''); ?> row">
        <i class="fa fas fa-project-diagram pr-1 col-2 my-auto"></i><span class="d-inline-block col-10">SAML Claims <?php echo request()->url() == route('claims') ? '<span class="sr-only">(current)</span>' : ''; ?></span>
    </li>
</a><?php /**PATH /Users/mobashirmonim/Documents/busso/resources/views/layouts/nav/items/claim.blade.php ENDPATH**/ ?>