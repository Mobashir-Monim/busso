<a class="nav-item container-fluid" href="<?php echo e(route('user-attributes')); ?>">
    <li class="nav-link text-white <?php echo e(startsWith(request()->url(), route('user-attributes')) ? 'active' : ''); ?> row">
        <i class="fab fa-creative-commons-by pr-1 col-2 my-auto"></i><span class="d-inline-block col-10"></i>User Attributes <?php echo request()->url() == route('user-attributes') ? '<span class="sr-only">(current)</span>' : ''; ?></span>
    </li>
</a>
<?php /**PATH /Users/mobashirmonim/Documents/busso/resources/views/layouts/nav/items/user-attribute.blade.php ENDPATH**/ ?>