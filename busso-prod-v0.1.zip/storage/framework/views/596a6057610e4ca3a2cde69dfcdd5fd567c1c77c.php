<a class="nav-item container-fluid" href="<?php echo e(route('user-attribute-values')); ?>">
    <li class="nav-link text-white <?php echo e(startsWith(request()->url(), route('user-attribute-values')) ? 'active' : ''); ?> row">
        <i class="fas fa-braille pr-1 col-2 my-auto"></i><span class="d-inline-block col-10"></i>User Attribute Values <?php echo request()->url() == route('user-attribute-values') ? '<span class="sr-only">(current)</span>' : ''; ?></span>
    </li>
</a><?php /**PATH /Users/mobashirmonim/Documents/busso/resources/views/layouts/nav/items/user-attribute-value.blade.php ENDPATH**/ ?>