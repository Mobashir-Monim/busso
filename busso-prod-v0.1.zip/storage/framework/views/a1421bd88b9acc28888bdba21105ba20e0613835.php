<?php $__env->startSection('content'); ?>
    <div class="row h-60">
        <div class="col-md-12 my-auto">
            <div class="row my-auto">
                <div class="col-md col-lg"></div>
                <div class="col-md-7 col-lg-5">
                    <div class="card card-login">
                        <div class="card-body">
                            <h3><?php echo e(isset(request()->SAMLRequest) || isset($oauth) ? 'BuSSO ' : ''); ?>Login</h3>
                            <form action="<?php echo e(!isset(request()->SAMLRequest) && !isset($oauth) ? route('login') : (
                                    !isset(request()->SAMLRequest) ?
                                        route('sso.oauth.login', ['oauth' => request()->oauth]) : route('sso.saml.assert-login', ['entity' => $entity->id])
                                )); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                
                                <?php if(isset(request()->SAMLRequest)): ?>
                                    <?php echo $__env->make('auth.sso.saml', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                <?php endif; ?>

                                <?php if(isset($oauth)): ?>
                                    <?php echo $__env->make('auth.sso.oauth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                <?php endif; ?>

                                <input type="email" name="email" id="email" class="form-control sso-inp  <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('email')); ?>" placeholder="Email Address" required autocomplete="email" autofocus>
                                
                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback text-right mb-2" role="alert"><?php echo e($message); ?></span>
                                <?php else: ?>
                                    <label for="email" class="sso-inp-label">Email</label>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                
                                <input type="password" name="password" id="password" class="form-control sso-inp  <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Password" required autocomplete="current-password">

                                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback text-right mb-2" role="alert"><?php echo e($message); ?></span>
                                <?php else: ?>
                                    <label for="password" class="sso-inp-label">Password</label>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                
                                <div class="row mt-4">
                                    <div class="col-md-6">
                                        <a class="btn btn-link" href="<?php echo e(route('password.request')); ?>">Forgot Password</a>
                                    </div>
                                    <div class="col-md-6 text-right">
                                        <button class="btn btn-dark" type="submit">Login</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                <div class="col-md col-lg"></div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('auth.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/mobashirmonim/Documents/busso/resources/views/auth/login.blade.php ENDPATH**/ ?>