<a class="nav-item container-fluid" href="<?php echo e(route('home')); ?>">
    <li class="nav-link text-white <?php echo e(request()->url() == route('home') ? 'active' : ''); ?> row">
        <i class="fa fas fa-home pr-1 col-2 my-auto"></i><span class="d-inline-block col-10">Dashboard <?php echo request()->url() == route('home') ? '<span class="sr-only">(current)</span>' : ''; ?></span>
    </li>
</a><?php /**PATH /Users/mobashirmonim/Documents/busso/resources/views/layouts/nav/items/dashboard.blade.php ENDPATH**/ ?>