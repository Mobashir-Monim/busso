<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <h3 class="border-bottom border-2 border-primary">Resource Groups</h3>
        </div>
    </div>
    <div class="row">
        <div class="col-md-12 mb-3 text-center">
            <?php $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="<?php echo e(route('resource-groups.show', ['group' => $group->id])); ?>" class="text-left">
                    <div class="card hoverable-card m-3">
                        <div class="card-img-top rg-image" style="background-image: url('<?php echo e(is_null($group->image) ? "/img/rg-placeholder.png" : Storage::url("$group->image")); ?>');"></div>
                        <div class="card-body">
                            <h5><?php echo e($group->name); ?></h5>
                        </div>
                    </div>
                </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>

    <button class="btn add-btn btn-dark" data-toggle="modal" data-target="#rg-create"></button>
    
    <?php echo e($groups->links()); ?>


    <?php echo $__env->make('resource-group.create', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        const typeInp = document.getElementById('type');
        const endpointInp = document.getElementById('endpoint');
        const oauthReq = ['oauth', 'both'];

        const setOnboarding = (type) => {
            typeInp.value = type;

            if (oauthReq.includes(type)) {
                endpointInp.required = true;
            } else {
                endpointInp.required = false;
            }
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/mobashirmonim/Documents/busso/resources/views/resource-group/index.blade.php ENDPATH**/ ?>