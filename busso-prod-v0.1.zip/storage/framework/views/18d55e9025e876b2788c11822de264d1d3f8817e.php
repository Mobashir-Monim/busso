<a class="nav-item container-fluid" href="<?php echo e(route('resource-groups')); ?>">
    <li class="nav-link text-white <?php echo e(startsWith(request()->url(), route('resource-groups')) ? 'active' : ''); ?> row">
        <i class="fa fas fa-layer-group pr-1 col-2 my-auto"></i><span class="d-inline-block col-10">Resource Group <?php echo request()->url() == route('resource-groups') ? '<span class="sr-only">(current)</span>' : ''; ?></span>
    </li>
</a><?php /**PATH /Users/mobashirmonim/Documents/busso/resources/views/layouts/nav/items/resource-group.blade.php ENDPATH**/ ?>