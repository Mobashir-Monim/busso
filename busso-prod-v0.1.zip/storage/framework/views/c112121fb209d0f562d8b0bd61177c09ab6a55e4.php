<a class="nav-item" href="#" id="claims-heading" type="button" data-toggle="collapse" data-target="#claims-container" aria-expanded="true" aria-controls="claims-container">
    <li class="nav-link text-white <?php echo e(request()->url() ? 'active' : ''); ?>">
        <i class="fa fas fa-home pr-1"></i>Scope <?php echo request()->url() ? '<span class="sr-only">(current)</span>' : ''; ?>

    </li>
</a>
<div id="collapseOne" class="collapse show" aria-labelledby="claims-heading" data-parent="#nav-accordion" id="claims-container">
    <div class="card-body">
        <ul class="collapse show text-white">
            <li>Scopes</li>
            <li>SAML Claim</li>
        </ul>
    </div>
</div>

<?php /**PATH /Users/mobashirmonim/Documents/busso/resources/views/layouts/nav/items/claims.blade.php ENDPATH**/ ?>