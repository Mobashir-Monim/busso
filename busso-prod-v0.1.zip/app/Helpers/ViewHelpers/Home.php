<?php

namespace App\Helpers\ViewHelpers;

use App\Helpers\Helper;

class Home extends Helper
{
    
}